<!doctype html>
<html lang="en">
<head>
  <title>  </title>
  <link rel="stylesheet" href="ex4.css">
  <script src ="ex4.js"></script>
  <!-- ----------------------------------
			BIS1523/BIS2523 Documentation
   Name:Andrew Banks
   Netid:alb1424
   Date:04/13/2021
   
   Variables used:
      <variable name>  <description of data variable will hold>
  
   -------------------------------------  -->
</head>
<body>
<div id="input">
    <form id ="dat" method=post action ="ex4.php">
        <input type="text" name="place"> <br />
        <button id ="Button">Search</button>
    </form>
</div>
<div id ="output">
    
</div>
</body>
</html>