<!doctype html>
<html lang="en">
<head>
  <title> </title>
  <link rel="stylesheet" href="jsintro.css">
  <script src="jsintro.js"></script>
</head>
<body>

<div id="mainarea">
	<p id="aline"> This is a paragraph with an id. </p>

	<p> This is a <span id="oneword">1</span> with an id. </p>

</div>
<br><hr><br>
<div id="outarea">
This is a div with an id.  
</div>
</body>
</html>