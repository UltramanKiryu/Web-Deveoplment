﻿<!doctype html>
<META HTTPEQUIV="CACHECONTROL" CONTENT="NOCACHE">
<meta httpequiv="expires" content="0" />
<html lang="en">
<head>
  <title>Purchasing</title>
  <link rel="stylesheet" href="purchasing.css">
  <script src="purchasing.js"> </script>
</head>
<body>

<div id="outarea"> 
</div>
</body>
</html>