<!doctype html>
<html lang="en">
<head>
  <title>  </title>
  <link rel="stylesheet" href="hw05.css">
  <script src="hw05.js"></script>
  <!-- ----------------------------------
			BIS1523/BIS2523 Documentation
   Name:Andrew Banks
   Netid:alb1424
   Date:03/11/2021
   
   Variables used:
      <variable name>  <description of data variable will hold>
  
   -------------------------------------  -->
</head>
<body>
    <div id= input>
        <form name="input" method=post action="hw05.php">
       Temperture: <input type="text" name="num"> <br />
    <input type="radio" name="temp" value="Farh"> Convert to Fahrenheit  </input><br />
    <input type="radio" name="temp" value="Cel"> Convet to Celcius </input> <br />
    <button id="Button">Calculate</button>

</form>
    </div>
<h2>
<div id="output">
   
</div>
</h2>


</body>
</html>