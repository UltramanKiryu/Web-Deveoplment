<!doctype html>
<html lang="en">
<head>
  <title>  </title>
  <link rel="stylesheet" href="hw07.css">
  <script src ="hw07.js"></script>
  <!-- ----------------------------------
			BIS1523/BIS2523 Documentation
   Name:Andrew Banks
   Netid:alb1424
   Date:04/01/2021
   
   Variables used:
      <variable name>  <description of data variable will hold>
  
   -------------------------------------  -->
</head>
<body>
    <div id= "input">
        <form name="input" method=post action="hw07.php">
       <input type="radio" name="cont" value="Africa"> Africa </input> <br />
    <input type="radio" name="cont" value="Australia/Oceania"> Australia/Oceania </input><br />
    <input type="radio" name="cont" value="Europe"> Europe</input><br />
    <input type="radio" name="cont" value="North America"> North America </input><br />
    <input type="radio" name="cont" value="South America"> South America</input>   <br />
    <button id ="Button">Search</button>

</form>
    </div>
    
<div id="output">
   
</div>


</body>
</html>