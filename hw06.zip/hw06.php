<!doctype html>
<html lang="en">
<head>
  <title>  </title>
  <link rel="stylesheet" href="hw06.css">
  <script src="hw06.js"></script> 
  <!-- ----------------------------------
			BIS1523/BIS2523 Documentation
   Name:Andrew Banks
   Netid:alb1424
   Date:03/24/2021
   
   Variables used:
      <variable name>  <description of data variable will hold>
  
   -------------------------------------  -->
</head>
<body>
<div id= input>
    <h2>hw06-Population Growth</h2>
        <form name="input" method=post action="hw06.php">
       Years to Forecast: <input type="text" name="time"> <br />
       Current Population: <input type="text" name="pop"> <br />
       Growth Rate: <input type="text" name="rate"> <br />
    <button id="Button">Calculate</button>

</form>
    </div>
<div id="output">
   
</div>
</body>
</html>